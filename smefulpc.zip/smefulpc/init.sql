-- init.sql — Инициализация базы данных SmefulPC
-- Запуск: psql -U postgres -f init.sql

-- Создаём базу данных
CREATE DATABASE smefulpc;

-- Подключаемся к ней
\c smefulpc;

CREATE TABLE IF NOT EXISTS users (
  id       SERIAL PRIMARY KEY,
  login    VARCHAR(100) UNIQUE NOT NULL,
  password TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
  id            SERIAL PRIMARY KEY,
  name          VARCHAR(255) NOT NULL,
  price         DECIMAL(10, 2) NOT NULL,
  description   TEXT,
  specs         TEXT,
  serial_number VARCHAR(100),
  image_url     TEXT,
  created_at    TIMESTAMP DEFAULT NOW()
);


CREATE TABLE IF NOT EXISTS orders (
  id              SERIAL PRIMARY KEY,
  customer_name   VARCHAR(255) NOT NULL,
  customer_email  VARCHAR(255),
  customer_phone  VARCHAR(50),
  items           JSONB,
  total           DECIMAL(10, 2),
  status          VARCHAR(50) DEFAULT 'new',
  created_at      TIMESTAMP DEFAULT NOW()
);

INSERT INTO products (name, price, description, specs, serial_number, image_url) VALUES
(
  'SmefulPC Gaming Pro X',
  89999.00,
  'Мощный игровой ПК для требовательных игр и профессиональных задач. Идеален для AAA-игр в 4K.',
  'CPU: Intel Core i9-14900K | GPU: NVIDIA RTX 4090 24GB | RAM: 64GB DDR5 6000MHz | SSD: 2TB NVMe PCIe 5.0 | Блок питания: 1000W Gold | Корпус: LIAN LI O11',
  'SPC-GP-001',
  'https://images.unsplash.com/photo-1587202372634-32705e3bf49c?w=500&q=80'
),
(
  'SmefulPC WorkStation Pro',
  64999.00,
  'Профессиональная рабочая станция для 3D-рендеринга, монтажа видео и машинного обучения.',
  'CPU: AMD Ryzen 9 7950X | GPU: NVIDIA RTX 4080 16GB | RAM: 128GB DDR5 4800MHz | SSD: 2TB + 2TB NVMe | HDD: 8TB | БП: 850W Platinum',
  'SPC-WS-002',
  'https://images.unsplash.com/photo-1593640408182-31c70c8268f5?w=500&q=80'
),
(
  'SmefulPC Home Office',
  34999.00,
  'Комфортный домашний ПК для работы, учёбы и лёгких игр. Оптимальный баланс цены и производительности.',
  'CPU: Intel Core i5-14600K | GPU: NVIDIA RTX 4060 8GB | RAM: 32GB DDR4 3600MHz | SSD: 1TB NVMe | БП: 650W Bronze | Корпус: DeepCool CH510',
  'SPC-HO-003',
  'https://images.unsplash.com/photo-1547082299-de196ea013d6?w=500&q=80'
),
(
  'SmefulPC Budget Start',
  19999.00,
  'Бюджетный игровой ПК для начинающих геймеров. Запустит все популярные игры на средних настройках.',
  'CPU: Intel Core i3-14100 | GPU: NVIDIA RTX 3060 12GB | RAM: 16GB DDR4 3200MHz | SSD: 512GB NVMe | БП: 550W Bronze',
  'SPC-BS-004',
  'https://images.unsplash.com/photo-1555680202-c86f0e12f086?w=500&q=80'
),
(
  'SmefulPC Streamer Edition',
  54999.00,
  'Специальная конфигурация для стриминга и создания контента. Стримь и играй одновременно без потери FPS.',
  'CPU: AMD Ryzen 7 7700X | GPU: NVIDIA RTX 4070 Ti 12GB | RAM: 32GB DDR5 | SSD: 2TB NVMe | HDD: 4TB | БП: 750W Gold | Capture Card: Elgato 4K60',
  'SPC-SE-005',
  'https://images.unsplash.com/photo-1591488320449-011701bb6704?w=500&q=80'
),
(
  'SmefulPC Mini Compact',
  28999.00,
  'Мощный компактный мини-ПК. Занимает минимум места, но не уступает полноразмерным системам.',
  'CPU: Intel Core i7-13700H | GPU: Intel Iris Xe + внешняя eGPU совместимость | RAM: 32GB LPDDR5 | SSD: 1TB NVMe | Wi-Fi 6E | Bluetooth 5.3',
  'SPC-MC-006',
  'https://images.unsplash.com/photo-1518770660439-4636190af475?w=500&q=80'
);
