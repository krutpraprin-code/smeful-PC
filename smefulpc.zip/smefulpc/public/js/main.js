// main.js — Логика главной страницы (каталог)

// ─── Корзина (хранится в localStorage) ─────────────────────
function getCart() {
  return JSON.parse(localStorage.getItem('smefulpc_cart') || '[]');
}
function saveCart(cart) {
  localStorage.setItem('smefulpc_cart', JSON.stringify(cart));
  updateCartCount();
}
function updateCartCount() {
  const cart  = getCart();
  const total = cart.reduce((sum, item) => sum + item.qty, 0);
  const el    = document.getElementById('cart-count');
  if (el) el.textContent = total;
}
// Добавить товар в корзину
function addToCart(id, name, price, image_url, serial_number) {
  const cart = getCart();
  const idx  = cart.findIndex(item => item.id === id);
  if (idx !== -1) {
    cart[idx].qty += 1;
  } else {
    cart.push({ id, name, price: parseFloat(price), image_url, serial_number, qty: 1 });
  }
  saveCart(cart);
  showToast(`✅ «${name}» добавлен в корзину`);
}
// ─── Уведомление (toast) ────────────────────────────────────
function showToast(message, isError = false) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = message;
  el.className   = 'toast' + (isError ? ' error' : '');
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 3000);
}
// ─── Форматирование цены ─────────────────────────────────────
function formatPrice(price) {
  return parseFloat(price).toLocaleString('ru-RU');
}
// ─── Загрузка товаров с сервера ─────────────────────────────
async function loadProducts(params = {}) {
  const loading = document.getElementById('loading');
  const grid    = document.getElementById('products-grid');
  if (!grid) return;
  loading.style.display = 'block';
  grid.innerHTML        = '';
  const query = new URLSearchParams();
  if (params.search)   query.set('search',   params.search);
  if (params.minPrice) query.set('minPrice', params.minPrice);
  if (params.maxPrice) query.set('maxPrice', params.maxPrice);
  try {
    const res      = await fetch('/api/products?' + query.toString());
    const products = await res.json();
    loading.style.display = 'none';
    if (!products.length) {
      grid.innerHTML = `
        <div class="no-products">
          <div class="icon">🔍</div>
          <h3>Товары не найдены</h3>
          <p>Попробуйте изменить параметры поиска</p>
        </div>`;
      return;
    }
    products.forEach(p => {
      grid.insertAdjacentHTML('beforeend', createProductCard(p));
    });
  } catch (err) {
    loading.style.display = 'none';
    grid.innerHTML = `
      <div class="no-products">
        <div class="icon">⚠️</div>
        <h3>Ошибка загрузки</h3>
        <p>Проверьте подключение к серверу</p>
      </div>`;
  }
}

// ─── Создание HTML карточки товара ──────────────────────────
function createProductCard(p) {
  const imgSrc = p.image_url || '';
  const imgEl  = imgSrc
    ? `<img src="${imgSrc}" alt="${p.name}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
    : '';
  const placeholder = `<div style="display:flex;align-items:center;justify-content:center;height:100%;font-size:4rem">🖥️</div>`;

  return `
    <div class="product-card" onclick="openModal(${p.id})">
      <div class="product-img-wrap">
        ${imgEl}
        <div style="display:none;align-items:center;justify-content:center;height:100%;font-size:4rem">🖥️</div>
        <div class="product-badge-available">В наличии</div>
      </div>
      <div class="product-info">
        <h3 class="product-name">${p.name}</h3>
        <p class="product-serial">Арт: ${p.serial_number || '—'}</p>
        <p class="product-desc">${p.description || ''}</p>
        <div class="product-footer">
          <span class="product-price">${formatPrice(p.price)} ₽</span>
          <button
            class="btn-add-cart"
            onclick="event.stopPropagation(); addToCart(${p.id}, '${p.name.replace(/'/g,"\\'")}', ${p.price}, '${(p.image_url||'').replace(/'/g,"\\'")}', '${(p.serial_number||'').replace(/'/g,"\\'")}')">
            В корзину
          </button>
        </div>
      </div>
    </div>`;
}

// ─── Модальное окно с деталями товара ───────────────────────
async function openModal(id) {
  try {
    const res = await fetch(`/api/products/${id}`);
    const p   = await res.json();

    const specsItems = (p.specs || '')
      .split('|')
      .map(s => s.trim())
      .filter(Boolean)
      .map(s => {
        const [key, ...rest] = s.split(':');
        return `<div class="specs-item">
          <span class="specs-key">${key.trim()}:</span>
          <span class="specs-val">${rest.join(':').trim()}</span>
        </div>`;
      })
      .join('');

    document.getElementById('modal-content').innerHTML = `
      ${p.image_url ? `<img src="${p.image_url}" class="modal-img" alt="${p.name}" onerror="this.style.display='none'">` : ''}
      <h2>${p.name}</h2>
      <p class="modal-serial">Артикул: ${p.serial_number || '—'}</p>
      <p class="modal-desc">${p.description || ''}</p>
      ${specsItems ? `
        <p class="modal-specs-title">⚙️ Характеристики</p>
        <div class="modal-specs">${specsItems}</div>
      ` : ''}
      <div class="modal-footer">
        <span class="modal-price">${formatPrice(p.price)} ₽</span>
        <button
          class="btn-primary"
          onclick="addToCart(${p.id}, '${p.name.replace(/'/g,"\\'")}', ${p.price}, '${(p.image_url||'').replace(/'/g,"\\'")}', '${(p.serial_number||'').replace(/'/g,"\\'")}'); closeModal()">
          🛒 В корзину
        </button>
      </div>`;

    document.getElementById('modal-overlay').classList.add('active');
  } catch (err) {
    showToast('Ошибка загрузки товара', true);
  }
}

function closeModal(e) {
  if (e && e.target !== document.getElementById('modal-overlay')) return;
  document.getElementById('modal-overlay').classList.remove('active');
}

// ─── Фильтрация ──────────────────────────────────────────────
function applyFilters() {
  loadProducts({
    search:   document.getElementById('search-input').value.trim(),
    minPrice: document.getElementById('min-price').value,
    maxPrice: document.getElementById('max-price').value
  });
}

function resetFilters() {
  document.getElementById('search-input').value = '';
  document.getElementById('min-price').value    = '';
  document.getElementById('max-price').value    = '';
  loadProducts();
}

// Поиск с задержкой (debounce) — не спамим запросами на каждый символ
let searchTimer;
function debounceSearch() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(applyFilters, 400);
}

// ─── Проверка авторизации ────────────────────────────────────
async function checkAuth() {
  try {
    const res  = await fetch('/api/me');
    const data = await res.json();
    const link = document.getElementById('admin-link');
    if (data.isAdmin && link) {
      link.textContent = '⚙️ Админ';
      link.href        = '/admin.html';
    }
  } catch {}
}

// ─── Инициализация при загрузке страницы ────────────────────
updateCartCount();
loadProducts();
checkAuth();
