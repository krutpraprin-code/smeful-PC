// cart.js — Логика страницы корзины

// ─── Работа с корзиной ───────────────────────────────────────
function getCart() {
  return JSON.parse(localStorage.getItem('smefulpc_cart') || '[]');
}
function saveCart(cart) {
  localStorage.setItem('smefulpc_cart', JSON.stringify(cart));
}
function formatPrice(price) {
  return parseFloat(price).toLocaleString('ru-RU');
}

// ─── Уведомление ─────────────────────────────────────────────
function showToast(message, isError = false) {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.className   = 'toast' + (isError ? ' error' : '');
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 3000);
}

// ─── Изменить количество ─────────────────────────────────────
function changeQty(id, delta) {
  const cart = getCart();
  const idx  = cart.findIndex(item => item.id === id);
  if (idx === -1) return;
  cart[idx].qty += delta;
  if (cart[idx].qty <= 0) cart.splice(idx, 1);
  saveCart(cart);
  renderCart();
}

// ─── Удалить товар ───────────────────────────────────────────
function removeItem(id) {
  const cart = getCart().filter(item => item.id !== id);
  saveCart(cart);
  renderCart();
  showToast('Товар удалён из корзины');
}

// ─── Очистить корзину ────────────────────────────────────────
function clearCart() {
  if (!confirm('Очистить корзину?')) return;
  saveCart([]);
  renderCart();
}

// ─── Отрисовка корзины ───────────────────────────────────────
function renderCart() {
  const cart      = getCart();
  const itemsEl   = document.getElementById('cart-items');
  const emptyEl   = document.getElementById('cart-empty');
  const layoutEl  = document.getElementById('cart-layout');
  const summaryEl = document.getElementById('cart-summary');
  const totalEl   = document.getElementById('cart-total-price');
  const countEl   = document.getElementById('cart-count');

  // Счётчик в шапке
  const totalQty = cart.reduce((s, i) => s + i.qty, 0);
  if (countEl) countEl.textContent = totalQty;

  if (cart.length === 0) {
    emptyEl.style.display  = 'block';
    layoutEl.style.display = 'none';
    return;
  }

  emptyEl.style.display  = 'none';
  layoutEl.style.display = 'grid';

  // Список товаров
  itemsEl.innerHTML = cart.map(item => `
    <div class="cart-item">
      <img
        class="cart-item-img"
        src="${item.image_url || ''}"
        alt="${item.name}"
        onerror="this.style.display='none'">
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-serial">Арт: ${item.serial_number || '—'}</div>
        <div class="cart-item-price">${formatPrice(item.price * item.qty)} ₽</div>
      </div>
      <div class="cart-item-controls">
        <button class="qty-btn" onclick="changeQty(${item.id}, -1)">−</button>
        <span class="qty-val">${item.qty}</span>
        <button class="qty-btn" onclick="changeQty(${item.id}, 1)">+</button>
        <button class="btn-remove" onclick="removeItem(${item.id})">Удалить</button>
      </div>
    </div>
  `).join('');

  // Итоговые строки
  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  summaryEl.innerHTML = cart.map(item => `
    <div class="cart-total-row">
      <span>${item.name} × ${item.qty}</span>
      <span>${formatPrice(item.price * item.qty)} ₽</span>
    </div>
  `).join('');

  totalEl.textContent = formatPrice(subtotal) + ' ₽';
}

// ─── Оформить заказ ──────────────────────────────────────────
async function placeOrder() {
  const cart  = getCart();
  const name  = document.getElementById('customer-name').value.trim();
  const phone = document.getElementById('customer-phone').value.trim();
  const email = document.getElementById('customer-email').value.trim();

  if (!name) {
    showToast('Введите ваше имя', true);
    document.getElementById('customer-name').focus();
    return;
  }
  if (cart.length === 0) {
    showToast('Корзина пуста', true);
    return;
  }

  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);

  try {
    const res  = await fetch('/api/orders', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({
        customer_name:  name,
        customer_phone: phone,
        customer_email: email,
        items:          cart,
        total:          total
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Ошибка оформления');

    // Очищаем корзину и показываем успех
    saveCart([]);
    document.getElementById('success-modal').classList.add('active');
  } catch (err) {
    showToast(err.message, true);
  }
}

// ─── Проверка авторизации ─────────────────────────────────────
async function checkAuth() {
  try {
    const res  = await fetch('/api/me');
    const data = await res.json();
    const link = document.getElementById('admin-link');
    if (data.isAdmin && link) {
      link.textContent = '⚙️ Админ';
      link.href        = '/admin.html';
    }
  } catch {}
}

// ─── Инициализация ───────────────────────────────────────────
renderCart();
checkAuth();
