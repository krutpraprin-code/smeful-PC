// admin.js — Логика административной панели

// ─── Проверка авторизации ─────────────────────────────────────
async function checkAdminAuth() {
  try {
    const res  = await fetch('/api/me');
    const data = await res.json();
    if (!data.isAdmin) {
      // Не авторизован — отправляем на страницу входа
      window.location.href = '/login.html';
      return;
    }
    const el = document.getElementById('admin-name');
    if (el) el.textContent = '👤 ' + data.login;
    loadProducts();
    loadOrders();
  } catch {
    window.location.href = '/login.html';
  }
}

// ─── Выйти ──────────────────────────────────────────────────────
async function doLogout() {
  await fetch('/api/logout', { method: 'POST' });
  window.location.href = '/login.html';
}

// ─── Переключение вкладок ────────────────────────────────────────
function switchTab(name) {
  document.querySelectorAll('.admin-panel').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
  document.getElementById('panel-' + name).classList.add('active');
  event.target.classList.add('active');
}

// ─── Уведомление ────────────────────────────────────────────────
function showToast(message, isError = false) {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.className   = 'toast' + (isError ? ' error' : '');
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 3000);
}

function formatPrice(price) {
  return parseFloat(price).toLocaleString('ru-RU');
}

// ──────────────────────────────────────────────────────────────
// РАБОТА С ТОВАРАМИ (CRUD)
// ──────────────────────────────────────────────────────────────

// Загрузить все товары и показать в таблице
async function loadProducts() {
  try {
    const res      = await fetch('/api/products');
    const products = await res.json();
    const tbody    = document.getElementById('products-tbody');

    if (products.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:20px;color:var(--text-dim)">Товаров нет. Добавьте первый!</td></tr>';
      return;
    }

    tbody.innerHTML = products.map(p => `
      <tr>
        <td style="color:var(--text-dim)">${p.id}</td>
        <td style="color:white;font-weight:600">${p.name}</td>
        <td style="color:var(--text-dim)">${p.serial_number || '—'}</td>
        <td style="color:var(--cyan);font-weight:700">${formatPrice(p.price)} ₽</td>
        <td>
          <button class="btn-edit" onclick="editProduct(${p.id})">✏️ Изменить</button>
          <button class="btn-delete" onclick="deleteProduct(${p.id}, '${p.name.replace(/'/g,"\\'")}')">🗑 Удалить</button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    showToast('Ошибка загрузки товаров', true);
  }
}
// Сохранить товар (добавить или обновить)
async function saveProduct() {
  const id     = document.getElementById('edit-id').value;
  const name   = document.getElementById('f-name').value.trim();
  const price  = document.getElementById('f-price').value;
  const serial = document.getElementById('f-serial').value.trim();
  const image  = document.getElementById('f-image').value.trim();
  const desc   = document.getElementById('f-desc').value.trim();
  const specs  = document.getElementById('f-specs').value.trim();
  if (!name || !price) {
    showToast('Заполните название и цену', true);
    return;
  }
  const body = { name, price: parseFloat(price), description: desc, specs, serial_number: serial, image_url: image };
  try {
    const url    = id ? `/api/products/${id}` : '/api/products';
    const method = id ? 'PUT' : 'POST';
    const res  = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(body)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    showToast(id ? '✅ Товар обновлён' : '✅ Товар добавлен');
    cancelEdit();
    loadProducts();
  } catch (err) {
    showToast('Ошибка: ' + err.message, true);
  }
}
// Заполнить форму данными товара для редактирования
async function editProduct(id) {
  try {
    const res = await fetch(`/api/products/${id}`);
    const p   = await res.json();
    document.getElementById('edit-id').value  = p.id;
    document.getElementById('f-name').value   = p.name;
    document.getElementById('f-price').value  = p.price;
    document.getElementById('f-serial').value = p.serial_number || '';
    document.getElementById('f-image').value  = p.image_url || '';
    document.getElementById('f-desc').value   = p.description || '';
    document.getElementById('f-specs').value  = p.specs || '';
    document.getElementById('form-title').textContent = '✏️ Редактировать товар';
    // Прокручиваем к форме
    document.querySelector('.product-form-card').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (err) {
    showToast('Ошибка загрузки товара', true);
  }
}
// Удалить товар
async function deleteProduct(id, name) {
  if (!confirm(`Удалить товар «${name}»?`)) return;
  try {
    const res = await fetch(`/api/products/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error();
    showToast('🗑 Товар удалён');
    loadProducts();
  } catch {
    showToast('Ошибка удаления', true);
  }
}
// Сбросить форму
function cancelEdit() {
  document.getElementById('edit-id').value    = '';
  document.getElementById('f-name').value     = '';
  document.getElementById('f-price').value    = '';
  document.getElementById('f-serial').value   = '';
  document.getElementById('f-image').value    = '';
  document.getElementById('f-desc').value     = '';
  document.getElementById('f-specs').value    = '';
  document.getElementById('form-title').textContent = '➕ Добавить товар';
}

// РАБОТА С ЗАКАЗАМИ
// Загрузить все заказы
async function loadOrders() {
  try {
    const res    = await fetch('/api/orders');
    const orders = await res.json();
    const tbody  = document.getElementById('orders-tbody');

    if (orders.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:20px;color:var(--text-dim)">Заказов пока нет</td></tr>';
      return;
    }

    tbody.innerHTML = orders.map(o => {
      const items    = Array.isArray(o.items) ? o.items : [];
      const itemsStr = items.map(i => `${i.name} × ${i.qty}`).join(', ');
      const date     = new Date(o.created_at).toLocaleString('ru-RU');

      const statusClass = {
        new:      'status-new',
        progress: 'status-progress',
        done:     'status-done'
      }[o.status] || 'status-new';

      const statusLabel = {
        new:      'Новый',
        progress: 'В работе',
        done:     'Выполнен'
      }[o.status] || 'Новый';

      return `
        <tr>
          <td style="color:var(--text-dim)">#${o.id}</td>
          <td style="color:white;font-weight:600">${o.customer_name}</td>
          <td style="color:var(--text-dim)">${o.customer_phone || '—'}</td>
          <td style="color:var(--cyan);font-weight:700">${formatPrice(o.total)} ₽</td>
          <td>
            <select class="form-input" style="padding:4px 8px;width:auto;font-size:0.82rem"
              onchange="updateOrderStatus(${o.id}, this.value)">
              <option value="new"      ${o.status==='new'      ? 'selected' : ''}>Новый</option>
              <option value="progress" ${o.status==='progress' ? 'selected' : ''}>В работе</option>
              <option value="done"     ${o.status==='done'     ? 'selected' : ''}>Выполнен</option>
            </select>
          </td>
          <td style="color:var(--text-dim);font-size:0.82rem">${date}</td>
          <td style="color:var(--text-dim);font-size:0.82rem;max-width:200px">${itemsStr}</td>
        </tr>`;
    }).join('');
  } catch (err) {
    showToast('Ошибка загрузки заказов', true);
  }
}

// Обновить статус заказа
async function updateOrderStatus(id, status) {
  try {
    await fetch(`/api/orders/${id}/status`, {
      method:  'PUT',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ status })
    });
    showToast('✅ Статус обновлён');
  } catch {
    showToast('Ошибка обновления статуса', true);
  }
}

// ─── Инициализация ───────────────────────────────────────────
checkAdminAuth();
