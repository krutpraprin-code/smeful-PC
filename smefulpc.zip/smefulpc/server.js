// server.js — Главный файл сервера SmefulPC
// Запуск: node server.js

const express = require('express');
const session = require('express-session');
const bcrypt   = require('bcrypt');
const path     = require('path');
const db       = require('./db');

const app  = express();
const PORT = 3000;

// ──────────────────────────────
// Middleware (промежуточное ПО)
// ──────────────────────────────

// Парсим JSON и URL-encoded тела запросов
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Раздаём статические файлы из папки public/
app.use(express.static(path.join(__dirname, 'public')));

// Сессии — нужны для авторизации
app.use(session({
  secret: 'smefulpc-super-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 } // 24 часа
}));

// Middleware для проверки админа
function isAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) {
    return next(); // пускаем дальше
  }
  res.status(401).json({ error: 'Нет доступа. Нужна авторизация.' });
}
// Создание первого администратора
async function initAdmin() {
  try {
    const result = await db.query('SELECT COUNT(*) FROM users');
    if (parseInt(result.rows[0].count) === 0) {
      const hash = await bcrypt.hash('admin123', 10);
      await db.query(
        'INSERT INTO users (login, password) VALUES ($1, $2)',
        ['admin', hash]
      );
      console.log('👤 Создан администратор: login=admin, password=admin123');
    }
  } catch (err) {
    console.error('Ошибка при создании администратора:', err.message);
  }
}
// Войти
app.post('/api/login', async (req, res) => {
  const { login, password } = req.body;
  try {
    const result = await db.query('SELECT * FROM users WHERE login = $1', [login]);
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Неверный логин или пароль' });
    }

    const user  = result.rows[0];
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(401).json({ error: 'Неверный логин или пароль' });
    }

    // Сохраняем в сессию
    req.session.isAdmin = true;
    req.session.userId  = user.id;
    req.session.login   = user.login;
    res.json({ success: true, login: user.login });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Выйти
app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

// Проверить текущего пользователя
app.get('/api/me', (req, res) => {
  res.json({
    isAdmin: !!req.session.isAdmin,
    login:   req.session.login || null
  });
});

// ══════════════════════════════
// МАРШРУТЫ ТОВАРОВ
// ══════════════════════════════

// Получить все товары (с фильтрацией)
app.get('/api/products', async (req, res) => {
  try {
    const { search, minPrice, maxPrice } = req.query;
    let query      = 'SELECT * FROM products';
    let conditions = [];
    let params     = [];

    if (search) {
      params.push(`%${search}%`);
      conditions.push(`(name ILIKE $${params.length} OR description ILIKE $${params.length})`);
    }
    if (minPrice && !isNaN(minPrice)) {
      params.push(parseFloat(minPrice));
      conditions.push(`price >= $${params.length}`);
    }
    if (maxPrice && !isNaN(maxPrice)) {
      params.push(parseFloat(maxPrice));
      conditions.push(`price <= $${params.length}`);
    }

    if (conditions.length > 0) {
      query += ' WHERE ' + conditions.join(' AND ');
    }
    query += ' ORDER BY id DESC';

    const result = await db.query(query, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Получить один товар по ID
app.get('/api/products/:id', async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM products WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Товар не найден' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Добавить товар (только для администратора)
app.post('/api/products', isAdmin, async (req, res) => {
  const { name, price, description, specs, serial_number, image_url } = req.body;
  try {
    const result = await db.query(
      `INSERT INTO products (name, price, description, specs, serial_number, image_url)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [name, price, description, specs, serial_number, image_url]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Изменить товар (только для администратора)
app.put('/api/products/:id', isAdmin, async (req, res) => {
  const { name, price, description, specs, serial_number, image_url } = req.body;
  try {
    const result = await db.query(
      `UPDATE products
       SET name=$1, price=$2, description=$3, specs=$4, serial_number=$5, image_url=$6
       WHERE id=$7 RETURNING *`,
      [name, price, description, specs, serial_number, image_url, req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Товар не найден' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Удалить товар (только для администратора)
app.delete('/api/products/:id', isAdmin, async (req, res) => {
  try {
    await db.query('DELETE FROM products WHERE id = $1', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ══════════════════════════════
// МАРШРУТЫ ЗАКАЗОВ
// ══════════════════════════════

// Оформить заказ (доступно всем)
app.post('/api/orders', async (req, res) => {
  const { customer_name, customer_email, customer_phone, items, total } = req.body;
  if (!customer_name || !items || items.length === 0) {
    return res.status(400).json({ error: 'Заполните имя и добавьте товары в корзину' });
  }
  try {
    const result = await db.query(
      `INSERT INTO orders (customer_name, customer_email, customer_phone, items, total)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [customer_name, customer_email, customer_phone, JSON.stringify(items), total]
    );
    res.json({ success: true, order: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Получить все заказы (только для администратора)
app.get('/api/orders', isAdmin, async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM orders ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Сменить статус заказа (только для администратора)
app.put('/api/orders/:id/status', isAdmin, async (req, res) => {
  const { status } = req.body;
  try {
    const result = await db.query(
      'UPDATE orders SET status=$1 WHERE id=$2 RETURNING *',
      [status, req.params.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ──────────────────────────────
// Запуск сервера
// ──────────────────────────────
app.listen(PORT, async () => {
  console.log(`\n🚀 Сервер SmefulPC запущен: http://localhost:${PORT}`);
  await initAdmin();
});
