// db.js — подключение к базе данных PostgreSQL
const { Pool } = require('pg');

// Настройки подключения к БД
// Измените эти данные под ваши настройки PostgreSQL
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'smefulpc',
  user: 'postgres',
  password: '1234' // <-- укажите ваш пароль от PostgreSQL
});

// Проверяем подключение при старте
pool.connect((err, client, release) => {
  if (err) {
    console.error('❌ Ошибка подключения к базе данных:', err.message);
  } else {
    console.log('✅ Подключение к PostgreSQL успешно!');
    release();
  }
});

// Экспортируем функцию запроса
module.exports = {
  query: (text, params) => pool.query(text, params)
};
